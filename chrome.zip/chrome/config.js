// Fichier de configuration par défaut
//const DEFAULT_SERVER_URL = "http://localhost:3000";
export const DEFAULT_SERVER_URL = "https://nqeyedpmyc.execute-api.eu-west-3.amazonaws.com/dev";